package lubao_5;

import battlecode.common.*;

public class ModifiedMove {

    static MapLocation t0;
    static Direction d0;
    static double v0;
    static double p0;
    static MapLocation t1;
    static Direction d1;
    static double v1;
    static double p1;
    static MapLocation t2;
    static Direction d2;
    static double v2;
    static double p2;
    static MapLocation t3;
    static Direction d3;
    static double v3;
    static double p3;
    static MapLocation t4;
    static Direction d4;
    static double v4;
    static double p4;
    static MapLocation t5;
    static Direction d5;
    static double v5;
    static double p5;
    static MapLocation t6;
    static Direction d6;
    static double v6;
    static double p6;
    static MapLocation t7;
    static Direction d7;
    static double v7;
    static double p7;
    static MapLocation t8;
    static Direction d8;
    static double v8;
    static double p8;
    static MapLocation t9;
    static Direction d9;
    static double v9;
    static double p9;
    static MapLocation t10;
    static Direction d10;
    static double v10;
    static double p10;
    static MapLocation t11;
    static Direction d11;
    static double v11;
    static double p11;
    static MapLocation t12;
    static Direction d12;
    static double v12;
    static double p12;
    static MapLocation t13;
    static Direction d13;
    static double v13;
    static double p13;
    static MapLocation t14;
    static Direction d14;
    static double v14;
    static double p14;
    static MapLocation t15;
    static Direction d15;
    static double v15;
    static double p15;
    static MapLocation t16;
    static Direction d16;
    static double v16;
    static double p16;
    static MapLocation t17;
    static Direction d17;
    static double v17;
    static double p17;
    static MapLocation t18;
    static Direction d18;
    static double v18;
    static double p18;
    static MapLocation t19;
    static Direction d19;
    static double v19;
    static double p19;
    static MapLocation t20;
    static Direction d20;
    static double v20;
    static double p20;
    static MapLocation t21;
    static Direction d21;
    static double v21;
    static double p21;
    static MapLocation t22;
    static Direction d22;
    static double v22;
    static double p22;
    static MapLocation t23;
    static Direction d23;
    static double v23;
    static double p23;
    static MapLocation t24;
    static Direction d24;
    static double v24;
    static double p24;
    static MapLocation t25;
    static Direction d25;
    static double v25;
    static double p25;
    static MapLocation t26;
    static Direction d26;
    static double v26;
    static double p26;
    static MapLocation t27;
    static Direction d27;
    static double v27;
    static double p27;
    static MapLocation t28;
    static Direction d28;
    static double v28;
    static double p28;
    static MapLocation t29;
    static Direction d29;
    static double v29;
    static double p29;
    static MapLocation t30;
    static Direction d30;
    static double v30;
    static double p30;
    static MapLocation t31;
    static Direction d31;
    static double v31;
    static double p31;
    static MapLocation t32;
    static Direction d32;
    static double v32;
    static double p32;
    static MapLocation t33;
    static Direction d33;
    static double v33;
    static double p33;
    static MapLocation t34;
    static Direction d34;
    static double v34;
    static double p34;
    static MapLocation t35;
    static Direction d35;
    static double v35;
    static double p35;
    static MapLocation t36;
    static Direction d36;
    static double v36;
    static double p36;
    static MapLocation t37;
    static Direction d37;
    static double v37;
    static double p37;
    static MapLocation t38;
    static Direction d38;
    static double v38;
    static double p38;
    static MapLocation t39;
    static Direction d39;
    static double v39;
    static double p39;
    static MapLocation t40;
    static Direction d40;
    static double v40;
    static double p40;
    static MapLocation t41;
    static Direction d41;
    static double v41;
    static double p41;
    static MapLocation t42;
    static Direction d42;
    static double v42;
    static double p42;
    static MapLocation t43;
    static Direction d43;
    static double v43;
    static double p43;
    static MapLocation t44;
    static Direction d44;
    static double v44;
    static double p44;
    static MapLocation t45;
    static Direction d45;
    static double v45;
    static double p45;
    static MapLocation t46;
    static Direction d46;
    static double v46;
    static double p46;
    static MapLocation t47;
    static Direction d47;
    static double v47;
    static double p47;
    static MapLocation t48;
    static Direction d48;
    static double v48;
    static double p48;
    static MapLocation t49;
    static Direction d49;
    static double v49;
    static double p49;
    static MapLocation t50;
    static Direction d50;
    static double v50;
    static double p50;
    static MapLocation t51;
    static Direction d51;
    static double v51;
    static double p51;
    static MapLocation t52;
    static Direction d52;
    static double v52;
    static double p52;
    static MapLocation t53;
    static Direction d53;
    static double v53;
    static double p53;
    static MapLocation t54;
    static Direction d54;
    static double v54;
    static double p54;
    static MapLocation t55;
    static Direction d55;
    static double v55;
    static double p55;
    static MapLocation t56;
    static Direction d56;
    static double v56;
    static double p56;
    static MapLocation t57;
    static Direction d57;
    static double v57;
    static double p57;
    static MapLocation t58;
    static Direction d58;
    static double v58;
    static double p58;
    static MapLocation t59;
    static Direction d59;
    static double v59;
    static double p59;
    static MapLocation t60;
    static Direction d60;
    static double v60;
    static double p60;
    static MapLocation t61;
    static Direction d61;
    static double v61;
    static double p61;
    static MapLocation t62;
    static Direction d62;
    static double v62;
    static double p62;
    static MapLocation t63;
    static Direction d63;
    static double v63;
    static double p63;
    static MapLocation t64;
    static Direction d64;
    static double v64;
    static double p64;
    static MapLocation t65;
    static Direction d65;
    static double v65;
    static double p65;
    static MapLocation t66;
    static Direction d66;
    static double v66;
    static double p66;
    static MapLocation t67;
    static Direction d67;
    static double v67;
    static double p67;
    static MapLocation t68;
    static Direction d68;
    static double v68;
    static double p68;

    static final Direction NORTH = Direction.NORTH;
    static final Direction SOUTH = Direction.SOUTH;
    static final Direction EAST = Direction.EAST;
    static final Direction WEST = Direction.WEST;
    static final Direction NORTH_EAST = Direction.NORTHEAST;
    static final Direction NORTH_WEST = Direction.NORTHWEST;
    static final Direction SOUTH_EAST = Direction.SOUTHEAST;
    static final Direction SOUTH_WEST = Direction.SOUTHWEST;

    static Direction getBestDir(RobotController rc, MapLocation target) {
        t0 = rc.getLocation();
        v0 = 0.00001;

        t1 = t0.add(WEST);
        v1 = 1000000;
        d1 = null;

        t2 = t0.add(SOUTH_WEST);
        v2 = 1000000;
        d2 = null;

        t3 = t0.add(SOUTH);
        v3 = 1000000;
        d3 = null;
        
        t4 = t0.add(SOUTH_EAST);
        v4 = 1000000;
        d4 = null;

        t5 = t0.add(EAST);
        v5 = 1000000;
        d5 = null;

        t6 = t0.add(NORTH_EAST);
        v6 = 1000000;
        d6 = null;

        t7 = t0.add(NORTH);
        v7 = 1000000;
        d7 = null;

        t8 = t0.add(NORTH_WEST);
        v8 = 1000000;
        d8 = null;

        try {
            
            if (rc.canSenseLocation(t1) && !rc.isLocationOccupied(t1)) {
                p1 = rc.senseRubble(t1) / 10;
                if (v1 > v0 + p1) {
                    v1 = v0 + p1;
                    d1 = WEST;
                }
            }
            if (rc.canSenseLocation(t2) && !rc.isLocationOccupied(t2)) {
                p2 = rc.senseRubble(t2) / 10;
                if (v2 > v0 + p2) {
                    v2 = v0 + p2;
                    d2 = SOUTH_WEST;
                }
            }
            if (rc.canSenseLocation(t3) && !rc.isLocationOccupied(t3)) {
                p3 = rc.senseRubble(t3) / 10;
                if (v3 > v0 + p3) {
                    v3 = v0 + p3;
                    d3 = SOUTH;
                }
            }
            if (rc.canSenseLocation(t4) && !rc.isLocationOccupied(t4)) {
                p4 = rc.senseRubble(t4) / 10;
                if (v4 > v0 + p4) {
                    v4 = v0 + p4;
                    d4 = SOUTH_EAST;
                }
            }
            if (rc.canSenseLocation(t5) && !rc.isLocationOccupied(t5)) {
                p5 = rc.senseRubble(t5) / 10;
                if (v5 > v0 + p5) {
                    v5 = v0 + p5;
                    d5 = EAST;
                }
            }
            if (rc.canSenseLocation(t6) && !rc.isLocationOccupied(t6)) {
                p6 = rc.senseRubble(t6) / 10;
                if (v6 > v0 + p6) {
                    v6 = v0 + p6;
                    d6 = NORTH_EAST;
                }
            }
            if (rc.canSenseLocation(t7) && !rc.isLocationOccupied(t7)) {
                p7 = rc.senseRubble(t7) / 10;
                if (v7 > v0 + p7) {
                    v7 = v0 + p7;
                    d7 = NORTH;
                }
            }
            if (rc.canSenseLocation(t8) && !rc.isLocationOccupied(t8)) {
                p8 = rc.senseRubble(t8) / 10;
                if (v8 > v0 + p8) {
                    v8 = v0 + p8;
                    d8 = NORTH_WEST;
                }
            }

            Direction answer = Direction.CENTER;
            double initialDistance = Math.sqrt(t0.distanceSquaredTo(target));
            double bestGuess = initialDistance;

            double dist1 = (initialDistance - Math.sqrt(t1.distanceSquaredTo(target))) / v1;
            if (dist1 > bestGuess) {
                bestGuess = dist1;
                answer = d1;
            }
            double dist2 = (initialDistance - Math.sqrt(t1.distanceSquaredTo(target))) / v2;
            if (dist2 > bestGuess) {
                bestGuess = dist2;
                answer = d2;
            }
            double dist3 = (initialDistance - Math.sqrt(t1.distanceSquaredTo(target))) / v3;
            if (dist3 > bestGuess) {
                bestGuess = dist3;
                answer = d3;
            }
            double dist4 = (initialDistance - Math.sqrt(t1.distanceSquaredTo(target))) / v4;
            if (dist4 > bestGuess) {
                bestGuess = dist4;
                answer = d4;
            }
            double dist5 = (initialDistance - Math.sqrt(t1.distanceSquaredTo(target))) / v5;
            if (dist5 > bestGuess) {
                bestGuess = dist5;
                answer = d5;
            }
            double dist6 = (initialDistance - Math.sqrt(t1.distanceSquaredTo(target))) / v6;
            if (dist6 > bestGuess) {
                bestGuess = dist6;
                answer = d6;
            }
            double dist7 = (initialDistance - Math.sqrt(t1.distanceSquaredTo(target))) / v7;
            if (dist7 > bestGuess) {
                bestGuess = dist7;
                answer = d7;
            }
            double dist8 = (initialDistance - Math.sqrt(t1.distanceSquaredTo(target))) / v8;
            if (dist7 > bestGuess) {
                bestGuess = dist8;
                answer = d8;
            }

            return answer;


        } catch (Exception e) {
            //TODO: handle exception
        }



        return Direction.CENTER; // TODO: This is not functional.
    }
}
